<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- AI calls use @lovable.dev/ai-gateway inside createServerFn handlers (src/lib/*.functions.ts); keeps keys and prompts server-side.
- Pages use the shared Page/Card/Stat shell in src/components/AppShell.tsx; keeps header and layout consistent across the four areas.
- ThemeProvider owns the shared light/dark state and browser preference; all pages use global semantic color tokens so switching stays consistent, with fixed cover tokens for text over dark course artwork.
- The standalone /login page is a frontend-only demonstration; form submission navigates to the student preview without sending or storing credentials or creating an authenticated session.
