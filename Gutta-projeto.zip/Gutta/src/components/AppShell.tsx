import { Link } from "@tanstack/react-router";
import { Bell, Search } from "lucide-react";
import type { ReactNode } from "react";
import { ThemeToggle } from "@/components/ThemeProvider";
import { Button } from "@/components/ui/button";

const nav = [
  { to: "/", label: "Início" },
  { to: "/aluno", label: "Área do Aluno" },
  { to: "/professor", label: "Painel do Professor" },
  { to: "/admin", label: "Admin" },
  { to: "/roteiro", label: "Tutor IA" },
] as const;

export function AppHeader({ overlay = false }: { overlay?: boolean }) {
  return (
    <header className={`${overlay ? "fixed bg-gradient-to-b from-background to-transparent" : "sticky border-b border-border bg-background/95 backdrop-blur"} inset-x-0 top-0 z-30 flex items-center justify-between px-6 py-4 md:px-12`}>
      <div className="flex items-center gap-8">
        <Link to="/" className="font-display text-3xl font-black tracking-tight text-primary">GUTTA</Link>
        <nav className="hidden gap-5 text-sm text-foreground/75 lg:flex">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/" }} activeProps={{ className: "font-semibold text-foreground" }} className="transition hover:text-foreground">
              {n.label}
            </Link>
          ))}
        </nav>
      </div>
      <div className="flex items-center gap-5">
        <ThemeToggle />
        <Button asChild variant="outline" size="sm"><Link to="/login">Entrar</Link></Button>
        <Search className="h-5 w-5" />
        <Bell className="h-5 w-5" />
        <Link to="/email" className="flex h-8 w-8 items-center justify-center rounded bg-primary text-sm font-bold text-primary-foreground">A</Link>
      </div>
    </header>
  );
}

export function Page({ title, subtitle, children, action }: { title: string; subtitle?: string; children: ReactNode; action?: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <AppHeader />
      <main className="mx-auto max-w-7xl px-6 py-10 md:px-12">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-4xl md:text-5xl">{title}</h1>
            {subtitle && <p className="mt-2 text-muted-foreground">{subtitle}</p>}
          </div>
          {action}
        </div>
        {children}
      </main>
    </div>
  );
}

export function Card({ title, children, className = "" }: { title?: string; children: ReactNode; className?: string }) {
  return (
    <section className={`rounded-md border border-border bg-card p-5 ${className}`}>
      {title && <h2 className="mb-4 font-display text-lg">{title}</h2>}
      {children}
    </section>
  );
}

export function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-md border border-border bg-card p-5">
      <p className="text-xs uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className="mt-2 font-display text-3xl">{value}</p>
      {hint && <p className="mt-1 text-xs text-primary">{hint}</p>}
    </div>
  );
}

export const btn = "inline-flex items-center justify-center gap-2 rounded bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition hover:bg-primary/85 disabled:opacity-50";
export const btnGhost = "inline-flex items-center justify-center gap-2 rounded border border-border px-5 py-2.5 text-sm font-semibold transition hover:bg-muted";
export const field = "w-full rounded border border-border bg-muted px-4 py-2.5 text-foreground outline-none focus:border-primary";
