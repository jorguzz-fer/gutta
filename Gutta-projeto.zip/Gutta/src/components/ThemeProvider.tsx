import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";

type Theme = "light" | "dark";
const ThemeContext = createContext<{ theme: Theme; toggle: () => void } | null>(null);
const storageKey = "gutta-theme";

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>("dark");

  useEffect(() => {
    let initial: Theme = "dark";
    try {
      const stored = window.localStorage.getItem(storageKey);
      if (stored === "light" || stored === "dark") initial = stored;
    } catch { /* Theme switching remains available without browser storage. */ }
    setTheme(initial);
    document.documentElement.classList.toggle("dark", initial === "dark");
  }, []);

  function toggle() {
    const next = theme === "dark" ? "light" : "dark";
    document.documentElement.classList.toggle("dark", next === "dark");
    setTheme(next);
    try { window.localStorage.setItem(storageKey, next); } catch { /* Optional persistence. */ }
  }

  return <ThemeContext.Provider value={{ theme, toggle }}>{children}</ThemeContext.Provider>;
}

export function ThemeToggle() {
  const context = useContext(ThemeContext);
  if (!context) return null;
  const label = context.theme === "dark" ? "Ativar tema claro" : "Ativar tema escuro";
  return (
    <Button variant="ghost" size="icon" onClick={context.toggle} aria-label={label} title={label}>
      {context.theme === "dark" ? <Sun /> : <Moon />}
    </Button>
  );
}