import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import { generateStudyPlan } from "@/lib/study-plan.functions";
import { ThemeToggle } from "@/components/ThemeProvider";

export const Route = createFileRoute("/roteiro")({
  head: () => ({
    meta: [
      { title: "Roteiro de estudo com IA — Gutta" },
      { name: "description", content: "Gere um roteiro de estudo de Medicina personalizado por tema, nível e tempo." },
      { property: "og:title", content: "Roteiro de estudo com IA — Gutta" },
      { property: "og:description", content: "Roteiros práticos e personalizados para estudantes de Medicina." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Roteiro,
});

function renderMd(md: string) {
  return md.split("\n").map((l, i) => {
    const t = l.replace(/\*\*(.+?)\*\*/g, "$1");
    if (/^#{1,2} /.test(l)) return <h2 key={i} className="mt-6 font-display text-2xl text-primary">{t.replace(/^#+ /, "")}</h2>;
    if (/^#{3,} /.test(l)) return <h3 key={i} className="mt-4 font-display text-lg">{t.replace(/^#+ /, "")}</h3>;
    if (/^\s*[-*] /.test(l)) return <li key={i} className="ml-5 list-disc text-foreground/85">{t.replace(/^\s*[-*] /, "")}</li>;
    if (/^\d+\. /.test(l)) return <p key={i} className="mt-2 font-semibold">{t}</p>;
    if (!l.trim()) return <div key={i} className="h-2" />;
    return <p key={i} className="text-foreground/85">{t}</p>;
  });
}

function Roteiro() {
  const gen = useServerFn(generateStudyPlan);
  const [topic, setTopic] = useState("");
  const [level, setLevel] = useState("iniciante");
  const [minutes, setMinutes] = useState(60);
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState("");
  const [error, setError] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError(""); setPlan("");
    try {
      const r = await gen({ data: { topic, level, minutes } });
      if (r.error) setError(r.error); else setPlan(r.plan);
    } catch {
      setError("Não foi possível gerar o roteiro agora.");
    } finally { setLoading(false); }
  }

  const field = "w-full rounded border border-border bg-muted px-4 py-3 text-foreground outline-none focus:border-primary";

  return (
    <div className="min-h-screen bg-background px-6 py-8 text-foreground md:px-12">
      <header className="flex items-center justify-between">
        <Link to="/" className="font-display text-3xl font-black text-primary">GUTTA</Link>
        <ThemeToggle />
      </header>
      <div className="mx-auto mt-10 max-w-3xl">
        <h1 className="font-display text-4xl md:text-5xl">Seu roteiro de estudo</h1>
        <p className="mt-2 text-muted-foreground">Diga o tema, seu nível e quanto tempo você tem. A IA monta o passo a passo.</p>
        <form onSubmit={submit} className="mt-8 grid gap-4 md:grid-cols-[1fr_180px_140px]">
          <input className={field} placeholder="Ex.: Insuficiência cardíaca" value={topic} onChange={(e) => setTopic(e.target.value)} required maxLength={200} />
          <select className={field} value={level} onChange={(e) => setLevel(e.target.value)}>
            <option value="iniciante">Iniciante</option>
            <option value="intermediário">Intermediário</option>
            <option value="avançado">Avançado</option>
          </select>
          <div className="relative">
            <input type="number" min={15} max={600} step={15} className={field} value={minutes} onChange={(e) => setMinutes(Number(e.target.value))} />
            <span className="absolute right-3 top-3.5 text-sm text-muted-foreground">min</span>
          </div>
          <button disabled={loading} className="flex items-center justify-center gap-2 rounded bg-primary px-6 py-3 font-semibold text-primary-foreground transition hover:bg-primary/85 disabled:opacity-60 md:col-span-3">
            {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Sparkles className="h-5 w-5" />}
            {loading ? "Gerando roteiro..." : "Gerar roteiro"}
          </button>
        </form>
        {error && <p className="mt-6 rounded border border-destructive p-4 text-destructive">{error}</p>}
        {plan && <article className="mt-8 rounded-md border border-border bg-card p-6 shadow-card">{renderMd(plan)}</article>}
      </div>
    </div>
  );
}
