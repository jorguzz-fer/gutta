import { createFileRoute, Link } from "@tanstack/react-router";
import { Play, Info, ChevronLeft, ChevronRight } from "lucide-react";
import { useRef, type CSSProperties } from "react";
import { AppHeader } from "@/components/AppShell";
import hero from "@/assets/hero.jpg";
import { rows, type Course } from "@/lib/courses";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Gutta — Cursos de Medicina" },
      { name: "description", content: "Plataforma de estudos para complementar seu aprendizado em Medicina." },
      { property: "og:title", content: "Gutta — Cursos de Medicina" },
      { property: "og:description", content: "Assista aulas de Cardiologia, Anatomia, Farmacologia e muito mais." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Row({ title, items }: { title: string; items: Course[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (d: number) => ref.current?.scrollBy({ left: d * ref.current.clientWidth * 0.8, behavior: "smooth" });
  return (
    <section className="group/row relative mb-10">
      <h2 className="mb-3 px-6 font-display text-xl text-foreground md:px-12">{title}</h2>
      <button onClick={() => scroll(-1)} aria-label="Anterior" className="absolute left-0 top-10 z-10 hidden h-[calc(100%-2.5rem)] w-10 items-center justify-center bg-background/60 opacity-0 transition group-hover/row:opacity-100 md:flex">
        <ChevronLeft className="text-foreground" />
      </button>
      <div ref={ref} className="no-scrollbar flex gap-3 overflow-x-auto scroll-smooth px-6 pb-4 md:px-12">
        {items.map((c) => (
          <Link key={c.slug} to="/curso/$slug" params={{ slug: c.slug }} className="group block w-64 shrink-0 cursor-pointer transition-transform duration-300 hover:z-10 hover:scale-105">
            <div
              className="course-cover relative flex aspect-video flex-col justify-end overflow-hidden rounded-md p-3 shadow-card"
              style={{ "--course-hue": c.hue } as CSSProperties}
            >
              <span className="absolute left-3 top-3 font-display text-xs font-bold text-primary">M</span>
              <p className="text-[10px] uppercase tracking-widest text-cover-muted">{c.area}</p>
              <h3 className="font-display text-lg leading-tight text-cover-foreground">{c.title}</h3>
              <div className="absolute inset-0 flex items-center justify-center bg-background/40 opacity-0 transition group-hover:opacity-100">
                <Play className="h-10 w-10 fill-cover-foreground text-cover-foreground" />
              </div>
              {c.progress !== undefined && (
                <div className="absolute bottom-0 left-0 h-1 w-full bg-muted">
                  <div className="h-full bg-primary" style={{ width: `${c.progress}%` }} />
                </div>
              )}
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{c.lessons} aulas</p>
          </Link>
        ))}
      </div>
      <button onClick={() => scroll(1)} aria-label="Próximo" className="absolute right-0 top-10 z-10 hidden h-[calc(100%-2.5rem)] w-10 items-center justify-center bg-background/60 opacity-0 transition group-hover/row:opacity-100 md:flex">
        <ChevronRight className="text-foreground" />
      </button>
    </section>
  );
}

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <AppHeader overlay />

      <section className="relative h-[85vh] min-h-[520px] w-full overflow-hidden">
        <img src={hero} alt="Coração humano anatômico" width={1920} height={1088} className="absolute inset-0 h-full w-full object-cover object-right md:object-center" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/60 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-background to-transparent" />
        <div className="relative z-10 flex h-full max-w-xl flex-col justify-center px-6 md:px-12">
          <p className="mb-2 text-xs font-semibold uppercase tracking-[0.3em] text-primary">Série original</p>
          <h1 className="font-display text-5xl font-black leading-none md:text-7xl">Cardiologia<br />Essencial</h1>
          <p className="mt-4 text-sm text-foreground/80 md:text-base">
            Do potencial de ação ao manejo da insuficiência cardíaca. 32 aulas com casos clínicos reais e questões de residência.
          </p>
          <div className="mt-6 flex gap-3">
            <Link to="/curso/$slug" params={{ slug: "fisiologia-cardiovascular" }} className="flex items-center gap-2 rounded bg-foreground px-6 py-2.5 font-semibold text-background transition hover:bg-foreground/80">
              <Play className="h-5 w-5 fill-background" /> Assistir
            </Link>
            <button className="flex items-center gap-2 rounded bg-muted/80 px-6 py-2.5 font-semibold transition hover:bg-muted">
              <Info className="h-5 w-5" /> Mais informações
            </button>
            <Link to="/roteiro" className="flex items-center gap-2 rounded bg-primary px-6 py-2.5 font-semibold text-primary-foreground transition hover:bg-primary/85">
              Criar roteiro com IA
            </Link>
          </div>
        </div>
      </section>

      <main className="relative z-10 -mt-24">
        {rows.map((r) => <Row key={r.title} {...r} />)}
      </main>
    </div>
  );
}
