import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import { getCourse } from "@/lib/courses";
import { ThemeToggle } from "@/components/ThemeProvider";

export const Route = createFileRoute("/curso/$slug")({
  loader: ({ params }) => {
    const course = getCourse(params.slug);
    if (!course) throw notFound();
    return course;
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.title} — Gutta` },
          { name: "description", content: loaderData.summary },
          { property: "og:title", content: `${loaderData.title} — Gutta` },
          { property: "og:description", content: loaderData.summary },
          { property: "og:type", content: "article" },
          { name: "twitter:card", content: "summary_large_image" },
        ]
      : [{ title: "Curso não encontrado — Gutta" }, { name: "robots", content: "noindex" }],
  }),
  notFoundComponent: () => (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background text-foreground">
      <p className="font-display text-2xl">Curso não encontrado</p>
      <Link to="/" className="text-primary">Voltar ao início</Link>
    </div>
  ),
  component: CoursePage,
});

function CoursePage() {
  const c = Route.useLoaderData();
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between px-6 py-5 md:px-12">
        <Link to="/" className="font-display text-3xl font-black text-primary">GUTTA</Link>
        <div className="flex items-center gap-4">
        <ThemeToggle />
        <Link to="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Voltar
        </Link>
        </div>
      </header>

      <div className="mx-auto max-w-5xl px-6 pb-20 md:px-12">
        <div className="aspect-video w-full overflow-hidden rounded-md bg-card shadow-card">
          <iframe
            className="h-full w-full"
            src={`https://www.youtube-nocookie.com/embed/${c.video.id}`}
            title={c.video.title}
            allow="accelerometer; encrypted-media; gyroscope; picture-in-picture; fullscreen"
            allowFullScreen
          />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">Vídeo: {c.video.title} · {c.video.channel} (em inglês)</p>

        <p className="mt-8 text-xs font-semibold uppercase tracking-[0.3em] text-primary">{c.area} · {c.lessons} aulas</p>
        <h1 className="mt-2 font-display text-4xl md:text-6xl">{c.title}</h1>
        <p className="mt-4 max-w-3xl text-lg text-foreground/80">{c.summary}</p>

        <div className="mt-12 grid gap-12 md:grid-cols-[1fr_280px]">
          <article className="space-y-10">
            {c.sections.map((s, i) => (
              <section key={s.title}>
                <h2 className="font-display text-2xl">
                  <span className="mr-3 text-primary">{String(i + 1).padStart(2, "0")}</span>{s.title}
                </h2>
                {s.body.map((p, j) => <p key={j} className="mt-3 leading-relaxed text-foreground/85">{p}</p>)}
                {i === 0 && (
                  <figure className="mt-6">
                    <img src={c.image} alt={c.imageAlt} width={1280} height={720} loading="lazy" className="w-full rounded-md" />
                    <figcaption className="mt-2 text-xs text-muted-foreground">{c.imageAlt}</figcaption>
                  </figure>
                )}
              </section>
            ))}
          </article>
          <aside className="h-fit rounded-md border border-border bg-card p-5 md:sticky md:top-6">
            <h3 className="font-display text-lg">Pontos-chave</h3>
            <ul className="mt-4 space-y-3">
              {c.keyPoints.map((k) => (
                <li key={k} className="flex gap-2 text-sm text-foreground/85">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />{k}
                </li>
              ))}
            </ul>
            <Link to="/roteiro" className="mt-6 block rounded bg-primary px-4 py-2.5 text-center text-sm font-semibold text-primary-foreground hover:bg-primary/85">
              Criar roteiro com IA
            </Link>
          </aside>
        </div>
      </div>
    </div>
  );
}
