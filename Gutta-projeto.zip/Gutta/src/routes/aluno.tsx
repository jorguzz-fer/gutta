import { createFileRoute, Link } from "@tanstack/react-router";
import { Flame, Trophy, Layers, HelpCircle, Sparkles, Users, Mail, Swords, Stethoscope, AlarmClock, BookOpen, Briefcase } from "lucide-react";
import { Page, Card, Stat, btn } from "@/components/AppShell";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/aluno")({
  head: () => meta("Área do Aluno", "Seu painel diário: questão do dia, flashcards, tutor IA, comunidades e mais."),
  component: Aluno,
});

const tools = [
  { to: "/questoes", icon: HelpCircle, label: "Banco de questões", desc: "Adaptativo, com comentários" },
  { to: "/flashcards", icon: Layers, label: "Flashcards", desc: "Revisão espaçada" },
  { to: "/roteiro", icon: Sparkles, label: "Tutor IA", desc: "Roteiros e explicações" },
  { to: "/comunidade", icon: Users, label: "Comunidades", desc: "Sua turma e ligas" },
  { to: "/email", icon: Mail, label: "Meu e-mail Gutta", desc: "Identidade acadêmica" },
  { to: "/questoes", icon: Swords, label: "Batalha", desc: "Desafie um colega" },
  { to: "/roteiro", icon: AlarmClock, label: "Revisão de prova", desc: "Trilha intensiva" },
] as const;

const agenda = [
  { d: "Seg", t: "Revisão: fisiopatologia da IC", k: "Aula" },
  { d: "Ter", t: "10 questões sobre AVC", k: "Questões" },
  { d: "Qua", t: "Caso clínico: insuficiência renal", k: "Caso" },
  { d: "Qui", t: "Monitoria de Fisiologia — 19h", k: "Monitoria" },
  { d: "Sex", t: "Simulado de Farmacologia", k: "Simulado" },
];

function Aluno() {
  return (
    <Page title="Bom dia, Ana" subtitle="Medicina · 3º semestre · Seu plano desta semana está pronto." action={<Link to="/onboarding" className="text-sm text-primary">Editar perfil</Link>}>
      <div className="grid gap-4 md:grid-cols-4">
        <Stat label="Sequência" value="12 dias" hint="Seu recorde é 18" />
        <Stat label="Questões na semana" value="146" hint="78% de acerto" />
        <Stat label="Cards para revisar" value="32" />
        <Stat label="Ranking da turma" value="#7" hint="Subiu 3 posições" />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card title="Questão do dia" className="lg:col-span-2">
          <p className="text-xs uppercase tracking-widest text-primary">Neurologia · Média</p>
          <p className="mt-2">Paciente com hemiparesia à direita e afasia de expressão. Qual artéria está mais provavelmente acometida?</p>
          <Link to="/questoes" className={`${btn} mt-4`}>Responder</Link>
        </Card>
        <Card title="Pontos a reforçar">
          <ul className="space-y-3 text-sm">
            {[["Equilíbrio ácido-base", 42], ["Vias neurológicas", 55], ["Antibióticos", 61]].map(([t, v]) => (
              <li key={t as string}>
                <div className="flex justify-between"><span>{t}</span><span className="text-muted-foreground">{v}%</span></div>
                <div className="mt-1 h-1.5 rounded bg-muted"><div className="h-full rounded bg-primary" style={{ width: `${v}%` }} /></div>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <h2 className="mb-4 mt-10 font-display text-2xl">Ferramentas</h2>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {tools.map((t) => (
          <Link key={t.label} to={t.to} className="group rounded-md border border-border bg-card p-4 transition hover:border-primary">
            <t.icon className="h-6 w-6 text-primary" />
            <p className="mt-3 font-semibold">{t.label}</p>
            <p className="text-xs text-muted-foreground">{t.desc}</p>
          </Link>
        ))}
        <Link to="/curso/$slug" params={{ slug: "gasometria-arterial" }} className="group rounded-md border border-border bg-card p-4 transition hover:border-primary">
          <Stethoscope className="h-6 w-6 text-primary" />
          <p className="mt-3 font-semibold">Caso clínico</p>
          <p className="text-xs text-muted-foreground">Paciente virtual</p>
        </Link>
      </div>

      <div className="mt-10 grid gap-6 lg:grid-cols-3">
        <Card title="Sua semana" className="lg:col-span-2">
          <ul className="divide-y divide-border">
            {agenda.map((a) => (
              <li key={a.t} className="flex items-center gap-4 py-3 text-sm">
                <span className="w-10 font-display text-primary">{a.d}</span>
                <span className="flex-1">{a.t}</span>
                <span className="rounded bg-muted px-2 py-0.5 text-xs">{a.k}</span>
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Conquistas">
          <div className="flex flex-wrap gap-3">
            {[Flame, Trophy, BookOpen, Briefcase].map((I, i) => (
              <div key={i} className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/15"><I className="h-6 w-6 text-primary" /></div>
            ))}
          </div>
          <p className="mt-4 text-sm text-muted-foreground">Faltam 6 dias seguidos para a conquista "Maratonista".</p>
        </Card>
      </div>
    </Page>
  );
}
