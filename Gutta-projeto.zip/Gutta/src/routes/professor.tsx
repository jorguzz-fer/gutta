import { createFileRoute } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { Page, Card, Stat, btn } from "@/components/AppShell";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/professor")({
  head: () => meta("Painel do Professor", "Venda aulas, cursos, monitorias e materiais na Gutta."),
  component: Professor,
});

const cursos = [["Fisiologia Cardiovascular", 1240, "R$ 89", "Publicado"], ["ECG na Prática", 860, "R$ 59", "Publicado"], ["Gasometria em 1 hora", 0, "R$ 29", "Em revisão"]] as const;
const sessoes = [["Hoje, 18h", "Ana Souza", "30 min · Ácido-base"], ["Amanhã, 10h", "Lucas Melo", "15 min · ECG"], ["Sex, 20h", "Monitoria em grupo", "60 min · 14 alunos"]] as const;

function Professor() {
  return (
    <Page title="Painel do Professor" subtitle="Profa. Helena Ribeiro · Cardiologia" action={<button className={btn}><Plus className="h-4 w-4" /> Novo conteúdo</button>}>
      <div className="grid gap-4 md:grid-cols-4">
        <Stat label="Receita no mês" value="R$ 8.420" hint="+18% vs. mês anterior" />
        <Stat label="Alunos ativos" value="2.100" />
        <Stat label="Avaliação média" value="4,8" />
        <Stat label="Sessões agendadas" value="9" />
      </div>
      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card title="Meus cursos" className="lg:col-span-2">
          <table className="w-full text-sm">
            <thead className="text-left text-xs uppercase text-muted-foreground"><tr><th className="pb-3">Curso</th><th>Alunos</th><th>Preço</th><th>Status</th></tr></thead>
            <tbody className="divide-y divide-border">
              {cursos.map(([n, a, p, s]) => (
                <tr key={n}><td className="py-3">{n}</td><td>{a}</td><td>{p}</td><td><span className={`rounded px-2 py-0.5 text-xs ${s === "Publicado" ? "bg-primary/20 text-primary" : "bg-muted"}`}>{s}</span></td></tr>
              ))}
            </tbody>
          </table>
        </Card>
        <Card title="Professor sob demanda">
          <ul className="space-y-3 text-sm">{sessoes.map(([d, w, t]) => <li key={d + w}><p className="font-semibold">{d} · {w}</p><p className="text-muted-foreground">{t}</p></li>)}</ul>
        </Card>
      </div>
    </Page>
  );
}
