import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Page, Card, btn } from "@/components/AppShell";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/questoes")({
  head: () => meta("Banco de questões", "Questões comentadas de Medicina com dificuldade adaptativa."),
  component: Questoes,
});

const qs = [
  { area: "Neurologia", q: "Paciente com hemiparesia à direita e afasia de expressão. Qual artéria está mais provavelmente acometida?", opts: ["Cerebral anterior direita", "Cerebral média esquerda", "Cerebral posterior esquerda", "Basilar"], a: 1, c: "A artéria cerebral média esquerda irriga a face lateral do hemisfério dominante, onde fica a área de Broca, e a área motora da face e do membro superior. Por isso a lesão causa afasia de expressão e hemiparesia contralateral." },
  { area: "Fisiologia", q: "Qual evento gera a primeira bulha cardíaca (B1)?", opts: ["Fechamento das valvas aórtica e pulmonar", "Abertura da valva mitral", "Fechamento das valvas mitral e tricúspide", "Enchimento ventricular rápido"], a: 2, c: "B1 marca o início da sístole e corresponde ao fechamento das valvas atrioventriculares." },
  { area: "Bioquímica", q: "Gasometria com pH 7,25, HCO₃⁻ 14 e PaCO₂ 29. Qual é o distúrbio?", opts: ["Acidose respiratória", "Acidose metabólica compensada", "Alcalose metabólica", "Distúrbio misto"], a: 1, c: "Pela fórmula de Winter, a PaCO₂ esperada é 1,5 × 14 + 8 = 29 ± 2. A compensação respiratória é adequada." },
];

function Questoes() {
  const [i, setI] = useState(0);
  const [pick, setPick] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const q = qs[i % qs.length]!;
  const answered = pick !== null;
  return (
    <Page title="Banco de questões" subtitle={`Modo adaptativo · ${score} acertos nesta sessão`}>
      <Card className="max-w-3xl">
        <p className="text-xs uppercase tracking-widest text-primary">{q.area} · Questão {i + 1}</p>
        <p className="mt-3 text-lg">{q.q}</p>
        <div className="mt-6 grid gap-2">
          {q.opts.map((o, j) => {
            const state = !answered ? "border-border hover:bg-muted" : j === q.a ? "border-primary bg-primary/20" : j === pick ? "border-destructive bg-destructive/15" : "border-border opacity-60";
            return (
              <button key={o} disabled={answered} onClick={() => { setPick(j); if (j === q.a) setScore((s) => s + 1); }} className={`rounded border p-3 text-left transition ${state}`}>
                <span className="mr-3 font-display text-primary">{"ABCD"[j]}</span>{o}
              </button>
            );
          })}
        </div>
        {answered && (
          <div className="mt-6 rounded bg-muted p-4 text-sm">
            <p className="font-semibold">{pick === q.a ? "Correto!" : "Resposta incorreta."}</p>
            <p className="mt-1 text-foreground/85">{q.c}</p>
            <button className={`${btn} mt-4`} onClick={() => { setI(i + 1); setPick(null); }}>Próxima questão</button>
          </div>
        )}
      </Card>
    </Page>
  );
}
