import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Page, btnGhost } from "@/components/AppShell";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/flashcards")({
  head: () => meta("Flashcards", "Flashcards de Medicina com revisão espaçada."),
  component: Flashcards,
});

const cards = [
  ["Fórmula de Winter", "PaCO₂ esperada = 1,5 × HCO₃⁻ + 8 ± 2"],
  ["Onde cruza o trato corticoespinhal?", "Na decussação das pirâmides, no bulbo"],
  ["Mecanismo dos betalactâmicos", "Inibem as PBPs e a síntese da parede celular"],
  ["MHC I apresenta para…", "Linfócitos T CD8"],
  ["Débito cardíaco", "Frequência cardíaca × volume sistólico"],
];

function Flashcards() {
  const [i, setI] = useState(0);
  const [flip, setFlip] = useState(false);
  const [done, setDone] = useState(0);
  const c = cards[i % cards.length]!;
  const next = () => { setFlip(false); setI(i + 1); setDone(done + 1); };
  return (
    <Page title="Flashcards" subtitle={`Revisão de hoje · ${done} de ${cards.length} revisados`}>
      <div className="mx-auto max-w-xl">
        <button onClick={() => setFlip(!flip)} className="flex aspect-[3/2] w-full flex-col items-center justify-center rounded-md border border-border bg-card p-8 text-center shadow-card transition hover:border-primary">
          <p className="text-xs uppercase tracking-widest text-muted-foreground">{flip ? "Resposta" : "Pergunta"}</p>
          <p className="mt-4 font-display text-2xl">{flip ? c[1] : c[0]}</p>
          {!flip && <p className="mt-6 text-xs text-muted-foreground">Clique para virar</p>}
        </button>
        {flip && (
          <div className="mt-6 grid grid-cols-3 gap-3">
            <button className={btnGhost} onClick={next}>Errei · 1 min</button>
            <button className={btnGhost} onClick={next}>Difícil · 1 dia</button>
            <button className={btnGhost} onClick={next}>Fácil · 4 dias</button>
          </div>
        )}
      </div>
    </Page>
  );
}
