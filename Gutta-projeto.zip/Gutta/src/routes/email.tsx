import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { Page, Card, btn, field } from "@/components/AppShell";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/email")({
  head: () => meta("Crie seu e-mail", "Sua identidade acadêmica digital com o domínio Gutta."),
  component: Email,
});

const usos = ["Certificados e portfólio de competências", "Feedback de simulados e avaliações", "Avisos de congressos, ligas e estágios", "Identidade para candidaturas e processos seletivos"];

function Email() {
  const [user, setUser] = useState("ana.souza");
  const [ads, setAds] = useState(false);
  const [done, setDone] = useState(false);
  const clean = user.toLowerCase().replace(/[^a-z0-9.]/g, "");
  return (
    <Page title="Crie seu e-mail Gutta" subtitle="Sua identidade acadêmica, num só lugar.">
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          {done ? (
            <div className="py-6 text-center">
              <CheckCircle2 className="mx-auto h-12 w-12 text-primary" />
              <p className="mt-4 font-display text-2xl">{clean}@gutta.com.br</p>
              <p className="mt-2 text-sm text-muted-foreground">Endereço reservado. O envio de e-mails será ativado em breve.</p>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setDone(true); }} className="space-y-4">
              <label className="block text-sm">Escolha seu endereço
                <div className="mt-1 flex items-center gap-2">
                  <input className={field} value={user} onChange={(e) => setUser(e.target.value)} required />
                  <span className="whitespace-nowrap text-muted-foreground">@gutta.com.br</span>
                </div>
              </label>
              <label className="flex items-start gap-2 text-sm text-foreground/85">
                <input type="checkbox" checked={ads} onChange={(e) => setAds(e.target.checked)} className="mt-1 accent-[var(--primary)]" />
                Aceito receber ofertas e novidades de parceiros (opcional, conforme a LGPD).
              </label>
              <button className={`${btn} w-full`} disabled={!clean}>Criar {clean || "…"}@gutta.com.br</button>
            </form>
          )}
        </Card>
        <Card title="Para que serve">
          <ul className="space-y-3">{usos.map((u) => <li key={u} className="flex gap-2 text-sm"><CheckCircle2 className="h-4 w-4 shrink-0 text-primary" />{u}</li>)}</ul>
          <p className="mt-5 rounded bg-primary/15 p-3 text-sm">Bônus: quem cria o e-mail ganha 30 dias de questões premium.</p>
        </Card>
      </div>
    </Page>
  );
}
