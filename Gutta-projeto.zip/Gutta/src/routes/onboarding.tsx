import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Page, Card, btn, field } from "@/components/AppShell";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/onboarding")({
  head: () => meta("Cadastro", "Conte seu curso, semestre e objetivos para personalizar seus estudos."),
  component: Onboarding,
});

const disciplinas = ["Anatomia", "Fisiologia", "Histologia", "Bioquímica", "Farmacologia", "Patologia", "Imunologia", "Microbiologia", "Semiologia"];
const objetivos = ["Passar nas provas", "Preparar para residência", "Revisar o ciclo básico", "Ganhar prática clínica"];

function Onboarding() {
  const nav = useNavigate();
  const [sel, setSel] = useState<string[]>(["Fisiologia"]);
  const [obj, setObj] = useState(objetivos[0]);
  const toggle = (d: string) => setSel((s) => (s.includes(d) ? s.filter((x) => x !== d) : [...s, d]));
  return (
    <Page title="Vamos personalizar seu estudo" subtitle="Leva 1 minuto. Você pode mudar depois.">
      <form className="grid max-w-3xl gap-6" onSubmit={(e) => { e.preventDefault(); nav({ to: "/aluno" }); }}>
        <Card title="Sobre você">
          <div className="grid gap-4 md:grid-cols-3">
            <label className="text-sm">Curso<input className={`${field} mt-1`} value="Medicina" readOnly /></label>
            <label className="text-sm">Instituição<input className={`${field} mt-1`} placeholder="Ex.: Faculdade de Medicina" required /></label>
            <label className="text-sm">Semestre
              <select className={`${field} mt-1`} defaultValue="3">{Array.from({ length: 12 }, (_, i) => <option key={i} value={i + 1}>{i + 1}º semestre</option>)}</select>
            </label>
          </div>
        </Card>
        <Card title="Disciplinas atuais">
          <div className="flex flex-wrap gap-2">
            {disciplinas.map((d) => (
              <button type="button" key={d} onClick={() => toggle(d)} className={`rounded-full border px-4 py-1.5 text-sm transition ${sel.includes(d) ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-muted"}`}>{d}</button>
            ))}
          </div>
        </Card>
        <Card title="Seu principal objetivo">
          <div className="grid gap-2 md:grid-cols-2">
            {objetivos.map((o) => (
              <button type="button" key={o} onClick={() => setObj(o)} className={`rounded border p-3 text-left text-sm transition ${obj === o ? "border-primary bg-primary/15" : "border-border hover:bg-muted"}`}>{o}</button>
            ))}
          </div>
        </Card>
        <button className={btn}>Montar meu painel</button>
      </form>
    </Page>
  );
}
