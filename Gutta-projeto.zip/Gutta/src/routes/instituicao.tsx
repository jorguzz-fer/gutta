import { createFileRoute } from "@tanstack/react-router";
import { Page, Card, Stat, btnGhost } from "@/components/AppShell";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/instituicao")({
  head: () => meta("Área Institucional", "Turmas, avaliações, relatórios e licenças para faculdades."),
  component: Inst,
});

const turmas = [["Medicina 2026.1", 3, 92, 81, "Baixo"], ["Medicina 2025.2", 4, 88, 74, "Médio"], ["Medicina 2025.1", 5, 95, 79, "Baixo"], ["Medicina 2024.2", 6, 71, 63, "Alto"]] as const;

function Inst() {
  return (
    <Page title="Área Institucional" subtitle="Faculdade de Medicina · Licença Campus (até 400 alunos)" action={<button className={btnGhost}>Exportar relatório</button>}>
      <div className="grid gap-4 md:grid-cols-4">
        <Stat label="Licenças em uso" value="342 / 400" />
        <Stat label="Engajamento semanal" value="86%" hint="+4 pontos" />
        <Stat label="Acerto médio" value="74%" />
        <Stat label="Alunos em risco" value="23" hint="Veja abaixo" />
      </div>
      <Card title="Turmas" className="mt-6">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted-foreground"><tr><th className="pb-3">Turma</th><th>Semestre</th><th>Engajamento</th><th>Acerto</th><th>Risco</th></tr></thead>
          <tbody className="divide-y divide-border">
            {turmas.map(([t, s, e, a, r]) => (
              <tr key={t}>
                <td className="py-3">{t}</td><td>{s}º</td>
                <td><div className="flex items-center gap-2"><div className="h-1.5 w-24 rounded bg-muted"><div className="h-full rounded bg-primary" style={{ width: `${e}%` }} /></div>{e}%</div></td>
                <td>{a}%</td>
                <td><span className={`rounded px-2 py-0.5 text-xs ${r === "Alto" ? "bg-destructive/20 text-destructive" : "bg-muted"}`}>{r}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <Card title="Próximas avaliações">
          <ul className="space-y-2 text-sm"><li>Simulado integrado do 3º semestre · 12/11</li><li>Prova de Farmacologia · 18/11</li><li>OSCE virtual · 25/11</li></ul>
        </Card>
        <Card title="Temas com mais erros">
          <ul className="space-y-2 text-sm"><li>Equilíbrio ácido-base · 58% de erro</li><li>Vias neurológicas · 47%</li><li>Antibioticoterapia · 41%</li></ul>
        </Card>
      </div>
    </Page>
  );
}
