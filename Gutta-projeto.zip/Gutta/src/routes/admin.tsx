import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Check, X } from "lucide-react";
import { Page, Card, Stat, btnGhost } from "@/components/AppShell";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/admin")({
  head: () => meta("Painel Admin", "Gestão da plataforma Gutta: usuários, receita, professores, conteúdo e contratos."),
  component: Admin,
});

const receita = [["Assinaturas", 48200], ["Cursos e aulas", 31500], ["Tutor IA premium", 18900], ["Contratos com faculdades", 62000], ["Comissões do marketplace", 7400]] as const;
const total = receita.reduce((s, [, v]) => s + v, 0);
const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });

const pendentesInicial = [
  { id: 1, tipo: "Professor", nome: "Dr. Rafael Costa", det: "Cardiologia · CRM-SP 123456" },
  { id: 2, tipo: "Curso", nome: "Gasometria em 1 hora", det: "Profa. Helena Ribeiro · 8 aulas" },
  { id: 3, tipo: "Professor", nome: "Dra. Marina Lopes", det: "Pediatria · CRM-RJ 654321" },
  { id: 4, tipo: "Denúncia", nome: "Post na Turma 2025.2", det: "Conteúdo fora do tema" },
];

const usuarios = [["Ana Souza", "Aluno", "Premium", "Hoje"], ["Helena Ribeiro", "Professor", "Verificado", "Hoje"], ["Lucas Melo", "Aluno", "Gratuito", "Ontem"], ["Faculdade de Medicina", "Instituição", "Licença Campus", "2 dias"], ["Bia Santos", "Aluno", "Premium", "3 dias"]] as const;

function Admin() {
  const [pend, setPend] = useState(pendentesInicial);
  const resolve = (id: number) => setPend((p) => p.filter((x) => x.id !== id));
  return (
    <Page title="Painel Admin" subtitle="Visão geral da empresa · Novembro 2026" action={<div className="flex gap-2"><Link to="/instituicao" className={btnGhost}>Instituições</Link><Link to="/marketplace" className={btnGhost}>Marketplace</Link></div>}>
      <div className="grid gap-4 md:grid-cols-4">
        <Stat label="Usuários ativos" value="18.420" hint="+1.240 no mês" />
        <Stat label="Assinantes pagos" value="2.310" hint="Conversão de 12,5%" />
        <Stat label="Receita no mês" value={brl(total)} hint="+22% vs. outubro" />
        <Stat label="Acesso diário" value="64%" hint="Meta: 70%" />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card title="Receita por fonte" className="lg:col-span-2">
          <ul className="space-y-4 text-sm">
            {receita.map(([n, v]) => (
              <li key={n}>
                <div className="flex justify-between"><span>{n}</span><span className="text-muted-foreground">{brl(v)}</span></div>
                <div className="mt-1 h-2 rounded bg-muted"><div className="h-full rounded bg-primary" style={{ width: `${(v / total) * 100}%` }} /></div>
              </li>
            ))}
          </ul>
        </Card>
        <Card title={`Aprovações pendentes (${pend.length})`}>
          {pend.length === 0 && <p className="text-sm text-muted-foreground">Tudo em dia.</p>}
          <ul className="space-y-3">
            {pend.map((p) => (
              <li key={p.id} className="flex items-center gap-3 text-sm">
                <div className="flex-1">
                  <p className="text-xs uppercase tracking-widest text-primary">{p.tipo}</p>
                  <p className="font-semibold">{p.nome}</p>
                  <p className="text-xs text-muted-foreground">{p.det}</p>
                </div>
                <button aria-label="Aprovar" onClick={() => resolve(p.id)} className="rounded bg-primary/20 p-1.5 text-primary hover:bg-primary/30"><Check className="h-4 w-4" /></button>
                <button aria-label="Recusar" onClick={() => resolve(p.id)} className="rounded bg-muted p-1.5 hover:bg-destructive/20"><X className="h-4 w-4" /></button>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card title="Usuários recentes" className="lg:col-span-2">
          <table className="w-full text-sm">
            <thead className="text-left text-xs uppercase text-muted-foreground"><tr><th className="pb-3">Nome</th><th>Tipo</th><th>Plano</th><th>Último acesso</th></tr></thead>
            <tbody className="divide-y divide-border">
              {usuarios.map(([n, t, p, a]) => <tr key={n}><td className="py-3">{n}</td><td>{t}</td><td>{p}</td><td className="text-muted-foreground">{a}</td></tr>)}
            </tbody>
          </table>
        </Card>
        <Card title="Saúde da plataforma">
          <ul className="space-y-3 text-sm">
            <li className="flex justify-between"><span>Professores verificados</span><span>148</span></li>
            <li className="flex justify-between"><span>Cursos publicados</span><span>312</span></li>
            <li className="flex justify-between"><span>Faculdades com contrato</span><span>9</span></li>
            <li className="flex justify-between"><span>E-mails Gutta criados</span><span>6.870</span></li>
            <li className="flex justify-between"><span>Pedidos de exclusão de dados (LGPD)</span><span>3</span></li>
          </ul>
        </Card>
      </div>
    </Page>
  );
}
