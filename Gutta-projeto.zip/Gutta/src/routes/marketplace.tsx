import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Page, btn } from "@/components/AppShell";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/marketplace")({
  head: () => meta("Marketplace", "Eventos, produtos, serviços e benefícios para estudantes de Medicina."),
  component: Market,
});

const items = [
  { k: "Eventos", t: "Congresso Brasileiro de Cardiologia (estudantes)", p: "R$ 180", d: "SP · 14–16/11" },
  { k: "Eventos", t: "Workshop de Suturas", p: "R$ 120", d: "Online + presencial" },
  { k: "Produtos", t: "Estetoscópio Littmann Classic III", p: "R$ 890", d: "15% off para membros" },
  { k: "Produtos", t: "Jaleco premium bordado", p: "R$ 149", d: "Entrega em 5 dias" },
  { k: "Serviços", t: "Mentoria de residência — 4 sessões", p: "R$ 390", d: "Com médicos R3" },
  { k: "Serviços", t: "Revisão de currículo Lattes", p: "R$ 79", d: "Entrega em 48 h" },
  { k: "Benefícios", t: "Desconto em livrarias médicas", p: "Grátis", d: "Até 20% off" },
  { k: "Benefícios", t: "Seguro de responsabilidade para estágio", p: "R$ 12/mês", d: "Parceiro credenciado" },
];
const cats = ["Todos", "Eventos", "Produtos", "Serviços", "Benefícios"];

function Market() {
  const [cat, setCat] = useState("Todos");
  const list = items.filter((i) => cat === "Todos" || i.k === cat);
  return (
    <Page title="Marketplace" subtitle="Tudo o que o estudante de Medicina precisa, com condições de membro.">
      <div className="mb-6 flex flex-wrap gap-2">
        {cats.map((c) => <button key={c} onClick={() => setCat(c)} className={`rounded-full border px-4 py-1.5 text-sm ${cat === c ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-muted"}`}>{c}</button>)}
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {list.map((i) => (
          <article key={i.t} className="flex flex-col rounded-md border border-border bg-card p-5">
            <span className="text-xs uppercase tracking-widest text-primary">{i.k}</span>
            <h3 className="mt-2 flex-1 font-semibold">{i.t}</h3>
            <p className="mt-2 text-xs text-muted-foreground">{i.d}</p>
            <div className="mt-4 flex items-center justify-between"><span className="font-display text-xl">{i.p}</span><button className={btn}>Ver</button></div>
          </article>
        ))}
      </div>
    </Page>
  );
}
