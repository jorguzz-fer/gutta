import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, BookOpen, Eye, EyeOff, LockKeyhole, Play, Sparkles } from "lucide-react";
import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ThemeToggle } from "@/components/ThemeProvider";
import { meta } from "@/lib/meta";
import heart from "@/assets/hero.jpg";

export const Route = createFileRoute("/login")({
  head: () => meta("Login", "Acesse a Gutta e continue seus estudos em Medicina e saúde."),
  component: Login,
});

const highlights = [
  { icon: Play, title: "Seu próximo passo começa aqui", text: "Aulas e cursos para acompanhar sua formação." },
  { icon: BookOpen, title: "Conhecimento que fica", text: "Questões e flashcards para revisar o que importa." },
  { icon: Sparkles, title: "Um estudo mais personalizado", text: "Roteiros com IA para o seu ritmo e seus objetivos." },
];

function Login() {
  const navigate = useNavigate();
  const [visible, setVisible] = useState(false);
  const [recovery, setRecovery] = useState(false);
  const [notice, setNotice] = useState("");

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (recovery) {
      setNotice("Esta é uma demonstração; nenhum e-mail de recuperação foi enviado.");
      return;
    }
    // Frontend preview only: no credentials are stored or sent, and no session is created.
    void navigate({ to: "/aluno" });
  }

  return (
    <main className="grid min-h-svh bg-background text-foreground lg:grid-cols-2">
      <section className="relative isolate hidden overflow-hidden bg-login-panel text-cover-foreground [&_.text-primary]:text-login-accent [&_.bg-primary]:bg-login-accent lg:flex lg:flex-col lg:justify-between lg:p-12 xl:p-16">
        <img src={heart} alt="Modelo anatômico de um coração humano" className="absolute right-0 top-0 -z-10 h-[60%] w-full object-cover object-right opacity-20" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-t from-login-panel via-login-panel/80 to-login-panel/40" />
        <Link to="/" className="w-fit font-display text-3xl" aria-label="Gutta — início">GUTTA<span className="text-primary">.</span></Link>
        <div className="my-14 max-w-lg">
          <p className="mb-6 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-cover-muted"><span className="h-1.5 w-1.5 rounded-full bg-primary" /> Sua formação em saúde, todos os dias</p>
          <h2 className="font-display text-4xl leading-tight xl:text-5xl">Mais conhecimento.<br />Mais confiança.<br /><span className="text-primary">Mais Gutta.</span></h2>
          <div className="my-7 h-1 w-12 bg-primary" />
          <p className="max-w-sm text-lg leading-relaxed text-cover-muted">Da primeira aula à prática clínica, um novo passo na sua jornada de aprendizado.</p>
        </div>
        <div className="space-y-3">
          {highlights.map(({ icon: Icon, title, text }) => (
            <div key={title} className="flex items-center gap-4 rounded-md border border-login-border bg-login-surface/70 p-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded bg-login-panel"><Icon className="h-5 w-5 text-primary" /></div>
              <div><h3 className="text-sm font-semibold">{title}</h3><p className="mt-0.5 text-sm text-cover-muted">{text}</p></div>
            </div>
          ))}
          <p className="pt-5 text-xs text-cover-muted">Gutta · Aprendizado para a vida.</p>
        </div>
      </section>

      <section className="relative flex min-h-svh flex-col px-6 py-6 sm:px-12">
        <div className="flex items-center justify-between">
          <Button asChild variant="ghost" size="sm"><Link to="/"><ArrowLeft /> Início</Link></Button>
          <ThemeToggle />
        </div>
        <div className="mx-auto flex w-full max-w-[380px] flex-1 flex-col justify-center py-12">
          <Link to="/" className="mb-9 w-fit font-display text-4xl text-primary">GUTTA<span className="text-foreground">.</span></Link>
          <h1 className="font-display text-2xl sm:text-3xl">{recovery ? "Esqueceu sua senha?" : "Bem-vindo de volta"}</h1>
          <p className="mb-8 mt-3 text-base leading-relaxed text-muted-foreground">{recovery ? "Informe o e-mail associado à sua conta." : "Seu próximo aprendizado está esperando. Acesse sua área de estudos."}</p>
          <form onSubmit={submit} className="space-y-5">
            <div className="space-y-2">
              <label htmlFor="login-email" className="text-sm font-semibold">E-mail</label>
              <Input id="login-email" name="email" type="email" autoComplete="email" placeholder="seu@email.com" required className="h-12 bg-muted/50 px-4" />
            </div>
            {!recovery && <div className="space-y-2">
              <div className="flex items-center justify-between gap-2"><label htmlFor="login-password" className="text-sm font-semibold">Senha</label><Button type="button" variant="link" className="h-auto p-0 text-xs" onClick={() => { setRecovery(true); setNotice(""); }}>Esqueci minha senha</Button></div>
              <div className="relative">
                <Input id="login-password" name="password" type={visible ? "text" : "password"} autoComplete="current-password" placeholder="Sua senha" required className="h-12 bg-muted/50 pl-4 pr-12" />
                <Button type="button" size="icon" variant="ghost" className="absolute right-1 top-1.5 text-muted-foreground" onClick={() => setVisible(!visible)} aria-label={visible ? "Ocultar senha" : "Mostrar senha"} title={visible ? "Ocultar senha" : "Mostrar senha"}>{visible ? <EyeOff /> : <Eye />}</Button>
              </div>
            </div>}
            <Button type="submit" className="h-12 w-full font-semibold">{recovery ? "Solicitar recuperação" : "Entrar"}<ArrowRight /></Button>
            {notice && <p role="status" className="text-sm text-muted-foreground">{notice}</p>}
          </form>
          <p className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-foreground"><LockKeyhole className="h-3.5 w-3.5" /> Modo demonstração · sem autenticação real</p>
          <div className="mt-8 border-t border-border pt-6 text-center text-sm">
            {recovery ? <Button variant="link" onClick={() => { setRecovery(false); setNotice(""); }}>Voltar para o login</Button> : <p className="text-muted-foreground">Ainda não tem uma conta? <Link to="/onboarding" className="font-semibold text-primary underline-offset-4 hover:underline">Cadastre-se</Link></p>}
          </div>
        </div>
        <p className="text-center text-xs text-muted-foreground">© {new Date().getFullYear()} Gutta. Aprendizado para a vida.</p>
      </section>
    </main>
  );
}