import { createFileRoute } from "@tanstack/react-router";
import { MessageSquare } from "lucide-react";
import { Page, Card, btn } from "@/components/AppShell";
import { meta } from "@/lib/meta";

export const Route = createFileRoute("/comunidade")({
  head: () => meta("Comunidades", "Grupos por turma, disciplina e ligas acadêmicas."),
  component: Comunidade,
});

const grupos = [["Turma 2026.1", 84], ["Liga de Cardiologia", 212], ["Fisiologia — Monitoria", 57], ["Liga de Emergência", 168]] as const;
const posts = [
  { a: "Lucas M.", g: "Turma 2026.1", t: "Alguém tem um resumo do ciclo de Krebs para a prova de sexta?", r: 12 },
  { a: "Profa. Helena", g: "Fisiologia — Monitoria", t: "Monitoria extra quinta, às 19h, sobre curvas pressão-volume.", r: 30 },
  { a: "Bia S.", g: "Liga de Cardiologia", t: "Inscrições abertas para o processo seletivo da liga!", r: 45 },
];

function Comunidade() {
  return (
    <Page title="Comunidades" subtitle="Estude com colegas da sua faculdade.">
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          {posts.map((p) => (
            <Card key={p.t}>
              <p className="text-xs text-muted-foreground">{p.a} · <span className="text-primary">{p.g}</span></p>
              <p className="mt-2">{p.t}</p>
              <p className="mt-3 flex items-center gap-1 text-xs text-muted-foreground"><MessageSquare className="h-3.5 w-3.5" /> {p.r} respostas</p>
            </Card>
          ))}
        </div>
        <Card title="Seus grupos">
          <ul className="space-y-3 text-sm">{grupos.map(([g, n]) => <li key={g} className="flex justify-between"><span>{g}</span><span className="text-muted-foreground">{n} membros</span></li>)}</ul>
          <button className={`${btn} mt-5 w-full`}>Criar sala de estudo</button>
        </Card>
      </div>
    </Page>
  );
}
