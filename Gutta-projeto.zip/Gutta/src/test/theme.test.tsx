import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import { ThemeProvider, ThemeToggle } from "@/components/ThemeProvider";

afterEach(() => {
  cleanup();
  window.localStorage.clear();
  document.documentElement.classList.remove("dark");
});

describe("Theme preference", () => {
  it("switches between light and dark and stores the choice", () => {
    render(<ThemeProvider><ThemeToggle /></ThemeProvider>);
    fireEvent.click(screen.getByRole("button", { name: "Ativar tema claro" }));
    expect(document.documentElement.classList.contains("dark")).toBe(false);
    expect(window.localStorage.getItem("gutta-theme")).toBe("light");
    fireEvent.click(screen.getByRole("button", { name: "Ativar tema escuro" }));
    expect(document.documentElement.classList.contains("dark")).toBe(true);
    expect(window.localStorage.getItem("gutta-theme")).toBe("dark");
  });

  it("restores a saved light preference", () => {
    window.localStorage.setItem("gutta-theme", "light");
    render(<ThemeProvider><ThemeToggle /></ThemeProvider>);
    expect(screen.getByRole("button", { name: "Ativar tema escuro" })).toBeInTheDocument();
    expect(document.documentElement.classList.contains("dark")).toBe(false);
  });
});