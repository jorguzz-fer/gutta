import { createServerFn } from "@tanstack/react-start";

export type StudyPlanInput = { topic: string; level: string; minutes: number };

export const generateStudyPlan = createServerFn({ method: "POST" })
  .inputValidator((d: StudyPlanInput) => {
    const topic = String(d.topic ?? "").trim().slice(0, 200);
    const level = ["iniciante", "intermediário", "avançado"].includes(d.level) ? d.level : "iniciante";
    const minutes = Math.min(600, Math.max(15, Number(d.minutes) || 60));
    if (!topic) throw new Error("Informe um tema.");
    return { topic, level, minutes };
  })
  .handler(async ({ data }) => {
    const { generateResponse, GatewayError } = await import("@lovable.dev/ai-gateway");
    try {
      const res = await generateResponse({
        model: "openai/gpt-6-astra",
        instructions:
          "Você é um preceptor de Medicina. Crie roteiros de estudo em português do Brasil, em Markdown, com: objetivo, etapas numeradas com tempo estimado (a soma deve caber no tempo disponível), atividades práticas (casos clínicos, questões, flashcards, esquemas), pontos de alta incidência em provas e uma autoavaliação final. Seja direto e clinicamente preciso.",
        input: `Tema: ${data.topic}\nNível: ${data.level}\nTempo disponível: ${data.minutes} minutos`,
      });
      let text = "";
      for (const item of res.output ?? []) {
        if (item.type === "message") {
          for (const c of item.content ?? []) if (c.type === "output_text") text += c.text;
        }
      }
      return { plan: text || "Não foi possível gerar o roteiro.", error: null as string | null };
    } catch (e) {
      console.error(e);
      const msg = e instanceof GatewayError && e.name === "PaymentRequiredError"
        ? "Créditos de IA esgotados. Tente mais tarde."
        : e instanceof GatewayError && e.name === "RateLimitError"
          ? "Muitas solicitações. Aguarde um pouco e tente novamente."
          : "Não foi possível gerar o roteiro agora.";
      return { plan: "", error: msg };
    }
  });
