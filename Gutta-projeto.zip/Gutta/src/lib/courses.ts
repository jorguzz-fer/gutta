import heart from "@/assets/lesson-heart.jpg";
import brain from "@/assets/lesson-brain.jpg";
import lungs from "@/assets/lesson-lungs.jpg";
import micro from "@/assets/lesson-micro.jpg";

export type Section = { title: string; body: string[] };
export type Course = {
  slug: string;
  title: string;
  area: string;
  hue: number;
  lessons: number;
  progress?: number | undefined;
  image: string;
  imageAlt: string;
  video: { id: string; title: string; channel: string };
  summary: string;
  sections: Section[];
  keyPoints: string[];
};

const V = {
  chf: { id: "ypYI_lmLD7g", title: "Congestive Heart Failure Explained", channel: "Osmosis" },
  cycle: { id: "xamYVlNF5Zo", title: "Cardiac Cycle", channel: "Ninja Nerd" },
  abx: { id: "SzJbAGbOcHI", title: "Antibiotics – Penicillins", channel: "Osmosis" },
  abg: { id: "tW1oXP9sw98", title: "Acid-Base Disorders", channel: "Ninja Nerd" },
  ecg: { id: "xIZQRjkwV9Q", title: "Electrocardiography (ECG) – basics", channel: "Osmosis" },
  neuron: { id: "qOmmqu6_g3s", title: "Neuron Anatomy & Function", channel: "Ninja Nerd" },
  immune: { id: "gR84OJ_EGxk", title: "Introduction to the immune system", channel: "Osmosis" },
  junctions: { id: "gmlA8V2zMv4", title: "Cell Junctions", channel: "Ninja Nerd" },
};

const H = { src: heart, alt: "Corte do coração mostrando câmaras e valvas" };
const B = { src: brain, alt: "Encéfalo em corte sagital e neurônios" };
const L = { src: lungs, alt: "Pulmões, árvore brônquica e alvéolos" };
const M = { src: micro, alt: "Lâmina histológica com células inflamatórias" };

function c(
  slug: string, title: string, area: string, hue: number, lessons: number,
  img: { src: string; alt: string }, video: Course["video"], summary: string,
  sections: Section[], keyPoints: string[], progress?: number,
): Course {
  return { slug, title, area, hue, lessons, progress, image: img.src, imageAlt: img.alt, video, summary, sections, keyPoints };
}

export const courses: Course[] = [
  c("fisiologia-cardiovascular", "Fisiologia Cardiovascular", "Cardiologia", 25, 24, H, V.cycle,
    "Entenda como o coração gera pressão e fluxo: ciclo cardíaco, débito cardíaco e regulação da pressão arterial.",
    [
      { title: "Ciclo cardíaco", body: ["O ciclo divide-se em sístole (contração isovolumétrica e ejeção) e diástole (relaxamento isovolumétrico e enchimento). A primeira bulha (B1) corresponde ao fechamento das valvas mitral e tricúspide; a segunda (B2), ao fechamento das valvas aórtica e pulmonar.", "A curva pressão-volume do ventrículo esquerdo resume o ciclo: a largura é o volume sistólico e a área interna representa o trabalho cardíaco."] },
      { title: "Débito cardíaco", body: ["DC = FC × volume sistólico. O volume sistólico depende de pré-carga (lei de Frank-Starling), pós-carga (resistência à ejeção) e contratilidade (inotropismo).", "Fração de ejeção = VS / volume diastólico final; o normal é acima de 50%."] },
      { title: "Regulação da pressão arterial", body: ["PA = DC × resistência vascular periférica. A curto prazo, os barorreceptores do seio carotídeo e do arco aórtico ajustam o tônus simpático; a longo prazo, o sistema renina-angiotensina-aldosterona e o rim controlam a volemia."] },
    ],
    ["B1 = fechamento das valvas AV; B2 = fechamento das semilunares", "DC = FC × VS", "Frank-Starling: mais estiramento, mais força (até um limite)", "SRAA regula a PA a longo prazo"], 62),
  c("neuroanatomia-essencial", "Neuroanatomia Essencial", "Neurologia", 260, 18, B, V.neuron,
    "Organização do sistema nervoso, do neurônio às grandes vias, com foco em localização de lesões.",
    [
      { title: "O neurônio", body: ["Dendritos recebem sinais, o corpo celular integra e o axônio conduz o potencial de ação até as sinapses. A bainha de mielina (oligodendrócitos no SNC, células de Schwann no SNP) permite a condução saltatória nos nodos de Ranvier."] },
      { title: "Grandes vias", body: ["Trato corticoespinhal: motricidade voluntária, cruza nas pirâmides do bulbo. Coluna dorsal-lemnisco medial: tato fino e propriocepção, cruza no bulbo. Trato espinotalâmico: dor e temperatura, cruza na medula logo após entrar.", "Por isso, a hemissecção medular (Brown-Séquard) causa perda motora e proprioceptiva do mesmo lado e perda de dor e temperatura do lado oposto."] },
      { title: "Neurônio motor superior × inferior", body: ["Lesão de neurônio motor superior: espasticidade, hiperreflexia e sinal de Babinski. Lesão de neurônio motor inferior: flacidez, hiporreflexia, atrofia e fasciculações."] },
    ],
    ["Corticoespinhal cruza no bulbo", "Espinotalâmico cruza na medula", "Babinski indica lesão de neurônio motor superior"], 30),
  c("antibioticoterapia", "Antibioticoterapia", "Infectologia", 150, 12, M, V.abx,
    "Classes de antibióticos, mecanismos de ação e como escolher o tratamento empírico.",
    [
      { title: "Mecanismos de ação", body: ["Parede celular: betalactâmicos (penicilinas, cefalosporinas, carbapenêmicos) e glicopeptídeos (vancomicina). Ribossomo: macrolídeos, aminoglicosídeos, tetraciclinas, clindamicina. DNA: fluoroquinolonas. Folato: sulfametoxazol-trimetoprima."] },
      { title: "Escolha empírica", body: ["Considere o sítio da infecção, os germes prováveis, a gravidade, a função renal, alergias e o perfil local de resistência. Colha culturas antes da primeira dose sempre que isso não atrasar o tratamento de casos graves.", "Reavalie em 48–72 h e descalone o esquema de acordo com as culturas."] },
      { title: "Resistência", body: ["Betalactamases inativam betalactâmicos (por isso se associam inibidores como clavulanato e tazobactam). O MRSA altera a PBP (PBP2a) e exige vancomicina, linezolida ou daptomicina."] },
    ],
    ["Colha culturas antes, se possível", "Descalone em 48–72 h", "MRSA: vancomicina ou linezolida"], 85),
  c("gasometria-arterial", "Gasometria Arterial", "Pneumologia", 210, 8, L, V.abg,
    "Interpretação passo a passo da gasometria e dos distúrbios ácido-base.",
    [
      { title: "Valores de referência", body: ["pH 7,35–7,45; PaCO₂ 35–45 mmHg; HCO₃⁻ 22–26 mEq/L; PaO₂ 80–100 mmHg."] },
      { title: "Roteiro de interpretação", body: ["1) O pH indica acidemia ou alcalemia? 2) O distúrbio primário é respiratório (PaCO₂) ou metabólico (HCO₃⁻)? 3) A compensação é adequada? Na acidose metabólica, use a fórmula de Winter: PaCO₂ esperada = 1,5 × HCO₃⁻ + 8 ± 2. 4) Na acidose metabólica, calcule o ânion gap: Na⁺ − (Cl⁻ + HCO₃⁻), normal em torno de 12."] },
      { title: "Causas de ânion gap aumentado", body: ["Cetoacidose, acidose lática, uremia e intoxicações (metanol, etilenoglicol, salicilatos)."] },
    ],
    ["Fórmula de Winter: 1,5 × HCO₃ + 8 ± 2", "AG = Na − (Cl + HCO₃)", "Sempre verifique se a compensação é adequada"], 15),
  c("ecg-na-pratica", "ECG na Prática", "Cardiologia", 10, 16, H, V.ecg,
    "Leitura sistemática do eletrocardiograma para o plantão.",
    [
      { title: "Sistemática de leitura", body: ["Ritmo, frequência, eixo, onda P, intervalo PR, QRS, segmento ST, onda T e intervalo QT, sempre nessa ordem.", "Frequência: 300 dividido pelo número de quadrados grandes entre duas ondas R (ou 1500 dividido pelo número de quadradinhos)."] },
      { title: "Intervalos normais", body: ["PR de 120 a 200 ms; QRS menor que 120 ms; QTc menor que cerca de 440 ms em homens e 460 ms em mulheres."] },
      { title: "Supra de ST", body: ["Supradesnivelamento em duas derivações contíguas sugere IAM com supra. Correlação: V1–V4, parede anterior (descendente anterior); II, III e aVF, parede inferior (geralmente coronária direita); I, aVL, V5 e V6, parede lateral (circunflexa)."] },
    ],
    ["FC = 300 / quadrados grandes", "PR de 120–200 ms; QRS < 120 ms", "II, III e aVF = parede inferior"], 48),
  c("clinica-medica-intensivo", "Clínica Médica Intensivo", "Revisão R1", 40, 60, H, V.chf,
    "Revisão dos temas de maior incidência em clínica médica para residência, começando por insuficiência cardíaca.",
    [
      { title: "Insuficiência cardíaca", body: ["Classifica-se pela fração de ejeção: reduzida (≤ 40%), levemente reduzida (41–49%) e preservada (≥ 50%). Sintomas típicos: dispneia, ortopneia, dispneia paroxística noturna e edema.", "Tratamento da ICFEr: os quatro pilares são o sacubitril-valsartana (ou IECA/BRA), betabloqueador, antagonista mineralocorticoide e inibidor de SGLT2."] },
      { title: "Perfis hemodinâmicos", body: ["Na descompensação, avalie congestão (úmido × seco) e perfusão (quente × frio). O perfil quente-úmido é o mais comum e trata-se com diurético."] },
    ],
    ["Quatro pilares da ICFEr", "Perfil quente-úmido: diurético", "Inibidor de SGLT2 reduz internações"]),
  c("emergencias-pediatricas", "Emergências Pediátricas", "Pediatria", 190, 22, L, V.abg,
    "Abordagem da criança grave pelo método ABCDE e principais emergências respiratórias.",
    [
      { title: "Avaliação inicial", body: ["Use o triângulo de avaliação pediátrica: aparência, trabalho respiratório e circulação da pele. Em seguida, siga o ABCDE."] },
      { title: "Bronquiolite e asma", body: ["Bronquiolite (geralmente por VSR em menores de 2 anos): o tratamento é de suporte, com oxigênio se SpO₂ < 90–92%, hidratação e aspiração nasal. Crise de asma: broncodilatador de curta ação, corticoide sistêmico e oxigênio conforme a saturação."] },
    ],
    ["Triângulo de avaliação pediátrica", "Bronquiolite: tratamento de suporte", "Asma: broncodilatador e corticoide"]),
  c("obstetricia-alto-risco", "Obstetrícia de Alto Risco", "GO", 330, 20, M, V.immune,
    "Síndromes hipertensivas, diabetes gestacional e outras condições de alto risco.",
    [
      { title: "Pré-eclâmpsia", body: ["PA ≥ 140/90 mmHg após 20 semanas, acompanhada de proteinúria ou de lesão de órgão-alvo. O sulfato de magnésio previne eclâmpsia (esquema de Zuspan ou Pritchard); a cura definitiva é o parto."] },
      { title: "Diabetes gestacional", body: ["Rastreio com glicemia de jejum na primeira consulta e TOTG de 75 g entre 24 e 28 semanas. O tratamento começa com dieta e atividade física; a insulina é a primeira escolha farmacológica."] },
    ],
    ["Sulfato de magnésio previne eclâmpsia", "TOTG 75 g entre 24 e 28 semanas", "Insulina é a primeira escolha no DMG"]),
  c("trauma-atls", "Trauma e ATLS", "Cirurgia", 0, 14, L, V.cycle,
    "Atendimento inicial ao politraumatizado segundo o ATLS.",
    [
      { title: "XABCDE", body: ["X: controle de hemorragia exsanguinante. A: via aérea com proteção da coluna cervical. B: ventilação. C: circulação e controle de sangramento. D: avaliação neurológica (Glasgow e pupilas). E: exposição com prevenção de hipotermia."] },
      { title: "Choque hemorrágico", body: ["Faça reposição balanceada de hemocomponentes e use ácido tranexâmico nas primeiras 3 horas. Limite os cristaloides para evitar coagulopatia."] },
    ],
    ["X vem antes do A", "Ácido tranexâmico nas primeiras 3 h", "Glasgow ≤ 8: intubar"]),
  c("psiquiatria-clinica", "Psiquiatria Clínica", "Psiquiatria", 280, 18, B, V.neuron,
    "Transtornos de humor e de ansiedade e o uso racional de psicofármacos.",
    [
      { title: "Depressão maior", body: ["São necessários 5 ou mais sintomas por pelo menos 2 semanas, incluindo humor deprimido ou anedonia. Os ISRS são a primeira linha; avalie a resposta em 4 a 6 semanas."] },
      { title: "Transtorno bipolar", body: ["Lítio e valproato são estabilizadores do humor. O lítio exige monitorar o nível sérico, a função renal e a tireoide."] },
    ],
    ["ISRS são a primeira linha na depressão", "Lítio: monitorar rim e tireoide", "Sempre avaliar o risco de suicídio"]),
  c("endocrinologia-basica", "Endocrinologia Básica", "Endócrino", 90, 15, M, V.abg,
    "Diabetes mellitus, tireoide e eixo hipotálamo-hipófise.",
    [
      { title: "Diabetes mellitus", body: ["Diagnóstico: glicemia de jejum ≥ 126 mg/dL, HbA1c ≥ 6,5%, TOTG de 2 h ≥ 200 mg/dL, ou glicemia casual ≥ 200 mg/dL com sintomas. A metformina é a primeira linha no DM2."] },
      { title: "Hipotireoidismo", body: ["TSH elevado com T4 livre baixo. A causa mais comum é a tireoidite de Hashimoto. O tratamento é com levotiroxina em jejum."] },
    ],
    ["HbA1c ≥ 6,5% fecha diagnóstico de DM", "Metformina é a primeira linha no DM2", "Hashimoto é a principal causa de hipotireoidismo"]),
  c("anatomia-humana", "Anatomia Humana", "Básico", 15, 40, H, V.cycle,
    "Fundamentos de anatomia sistêmica, começando pelo coração e pelos grandes vasos.",
    [
      { title: "Anatomia do coração", body: ["Quatro câmaras: os átrios recebem sangue e os ventrículos ejetam. As valvas atrioventriculares são a tricúspide (à direita) e a mitral (à esquerda); as semilunares são a pulmonar e a aórtica.", "Irrigação: a coronária direita irriga o VD, a parede inferior e, na maioria das pessoas, os nós sinusal e AV. A coronária esquerda se divide em descendente anterior e circunflexa."] },
    ],
    ["Mitral à esquerda, tricúspide à direita", "Descendente anterior irriga a parede anterior e o septo"]),
  c("histologia", "Histologia", "Básico", 300, 26, M, V.junctions,
    "Os quatro tecidos fundamentais e as junções celulares.",
    [
      { title: "Tecidos fundamentais", body: ["Epitelial, conjuntivo, muscular e nervoso. O epitélio é avascular, nutrido por difusão a partir do conjuntivo, e classifica-se pelo número de camadas e pela forma das células."] },
      { title: "Junções celulares", body: ["Junções de oclusão (tight junctions) vedam o espaço intercelular; desmossomos dão adesão mecânica; junções comunicantes (gap junctions) permitem a passagem de íons; hemidesmossomos prendem a célula à lâmina basal."] },
    ],
    ["Epitélio é avascular", "Gap junctions acoplam eletricamente as células"]),
  c("bioquimica-medica", "Bioquímica Médica", "Básico", 170, 30, M, V.abg,
    "Metabolismo energético e sua aplicação clínica.",
    [
      { title: "Metabolismo da glicose", body: ["A glicólise ocorre no citosol e gera piruvato. Com oxigênio, o piruvato entra no ciclo de Krebs e na fosforilação oxidativa; sem oxigênio, vira lactato, o que explica a acidose lática no choque."] },
      { title: "Corpos cetônicos", body: ["No jejum prolongado ou na falta de insulina, a betaoxidação gera acetil-CoA em excesso, que o fígado converte em corpos cetônicos. Esse é o mecanismo da cetoacidose diabética."] },
    ],
    ["Hipóxia leva a lactato e acidose", "Falta de insulina leva a cetogênese"]),
  c("farmacologia-geral", "Farmacologia Geral", "Básico", 60, 28, M, V.abx,
    "Farmacocinética e farmacodinâmica essenciais.",
    [
      { title: "Farmacocinética", body: ["Absorção, distribuição, metabolismo e excreção. A meia-vida é o tempo para a concentração cair pela metade; o estado de equilíbrio é atingido em 4 a 5 meias-vidas."] },
      { title: "Farmacodinâmica", body: ["Agonistas ativam receptores; antagonistas competitivos deslocam a curva dose-resposta para a direita sem reduzir o efeito máximo. Índice terapêutico = DT50 / DE50."] },
    ],
    ["Equilíbrio em 4–5 meias-vidas", "Antagonista competitivo não reduz o efeito máximo"]),
  c("imunologia", "Imunologia", "Básico", 230, 20, M, V.immune,
    "Imunidade inata e adaptativa e suas células.",
    [
      { title: "Imunidade inata", body: ["É rápida e inespecífica: barreiras, neutrófilos, macrófagos, células NK e sistema complemento. Reconhece padrões moleculares de patógenos por meio de receptores como os TLRs."] },
      { title: "Imunidade adaptativa", body: ["É específica e tem memória. Os linfócitos B produzem anticorpos; os T CD4 coordenam a resposta e os T CD8 destroem células infectadas. A apresentação de antígeno ocorre via MHC II para CD4 e MHC I para CD8."] },
    ],
    ["MHC I apresenta para CD8; MHC II para CD4", "Inata é rápida; adaptativa tem memória"]),
  c("microbiologia", "Microbiologia", "Básico", 120, 22, M, V.immune,
    "Bactérias de importância clínica e a coloração de Gram.",
    [
      { title: "Coloração de Gram", body: ["Gram-positivas têm parede espessa de peptidoglicano e coram em roxo. Gram-negativas têm membrana externa com LPS (endotoxina) e coram em rosa."] },
      { title: "Principais agentes", body: ["S. aureus: cocos Gram-positivos em cachos, coagulase-positivo. S. pneumoniae: diplococos Gram-positivos, principal causa de pneumonia comunitária. E. coli: bacilo Gram-negativo, principal causa de infecção urinária."] },
    ],
    ["Gram-negativas têm LPS", "Pneumococo é a principal causa de pneumonia comunitária", "E. coli é a principal causa de ITU"]),
];

export const getCourse = (slug: string) => courses.find((x) => x.slug === slug);

const pick = (slugs: string[]) => slugs.map((s) => getCourse(s)!).filter(Boolean);

export const rows = [
  { title: "Continuar estudando", items: pick(["fisiologia-cardiovascular", "neuroanatomia-essencial", "antibioticoterapia", "gasometria-arterial", "ecg-na-pratica"]) },
  { title: "Em alta na residência", items: pick(["clinica-medica-intensivo", "emergencias-pediatricas", "obstetricia-alto-risco", "trauma-atls", "psiquiatria-clinica", "endocrinologia-basica"]) },
  { title: "Ciclo básico", items: pick(["anatomia-humana", "histologia", "bioquimica-medica", "farmacologia-geral", "imunologia", "microbiologia"]) },
];
