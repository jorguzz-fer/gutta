export const meta = (title: string, description: string) => ({
  meta: [
    { title: `${title} — Gutta` },
    { name: "description", content: description },
    { property: "og:title", content: `${title} — Gutta` },
    { property: "og:description", content: description },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ],
});
